package com.koushikdutta.async.callback;

public interface WritableCallback {
    public void onWriteable();
}
