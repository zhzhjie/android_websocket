package com.koushikdutta.async.http;

public class BodyDecoderException extends Exception {
    public BodyDecoderException(String message) {
        super(message);
    }
}
