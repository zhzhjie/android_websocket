package com.koushikdutta.async.http.socketio;

/**
 * Created by koush on 8/1/13.
 */
public interface ExceptionCallback {
    public void onException(Exception e);
}
